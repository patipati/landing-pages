function fancy() {
	$('.fancy').fancybox({
		openEffect	: 'none',
		closeEffect	: 'none',
		helpers	: {
			overlay : {
				locked : false
			},
			title	: {
				type: 'over'
			}
		},
		tpl : {
			next     : '<a title="Следущая" class="fancybox-nav fancybox-next" href="javascript:;"><span></span></a>',
			prev     : '<a title="Предыдущая" class="fancybox-nav fancybox-prev" href="javascript:;"><span></span></a>',
			closeBtn : '<a title="Закрыть" class="fancybox-item fancybox-close" href="javascript:;"></a>'
		}
	});
}

function toggleId() {
	$('.toggleId').on('click', function(event){
		event.preventDefault();
		$($(this).toggleClass('open').attr('href')).fadeToggle('slow');
	});
}

function ScrollTop() {
	$(window).scroll(function(){
		if( $(window).scrollTop() < $(window).height() / 2 ) {
			$('#scroll_top').hide();
		}
		else {
			$('#scroll_top').show();
		}
	});

	$('#scroll_top').hide().click(function(){
		$('html, body').animate({scrollTop: 0}, 1000);
	});
}


function scrollTo() {
	$('.scrollTo').click(function(event){
		event.preventDefault();
		var hrefId = $(this).attr('href');
		var posTop = $(hrefId).offset().top;
		$('html, body').animate({scrollTop: posTop}, 1000);
	});
}
function fakeSelect() {
	$('.fakeSelect').click(function (){
		$(this).children('.innerlink').fadeIn();
	});

	$(document).bind('click', function(e) {
		if ($(e.target).closest('.fakeSelect').length == 0) {
			$('.innerlink').fadeOut();
		}
	});
}

function grabFooter() {
	var domain = 'http://synergy.edu.ru/';
	$('.footer').load( domain + ' .grab', function() {
		$('.footer .copyright #curY').text((new Date).getFullYear());
		fakeSelect();
		$('.footer a').each(function(){
			var href = $(this).attr('href');
			$(this).attr({
				'href': domain + href,
				'target' : '_blank'
			});
		});
	});
}

$(document).ready(function(){
	fancy();
	ScrollTop();
	toggleId();
	scrollTo();
	//grabFooter();

    $('input[type="radio"]').change(function(){
        $("form").attr('radio', $('input[type="radio"]:checked').val());
    })
});