


/* Carousel ----------------------------------------------------------------------------------------------------------*/
$(function(){

    $('.carousel').bxSlider({
        controls:true

    });


});
/* Popup ----------------------------------------------------------------------------------------------------------*/
$(document).ready(function() {
	$(window).on('scroll touchmove touchend', function() {
        var scrolledpx = parseInt($(window).scrollTop()); 
		
		$('.popup-link').click(function() {
			var imData = $(this).attr('data');
            var obj = $('.popup[data="'+imData+'"]');
			$('.hidelayout').fadeIn(300);
			$(obj).fadeIn(300).css('top', scrolledpx + 100);
			return false;
		});
		$('.popup .close, .hidelayout').click(function() {
			$('.hidelayout, .popup').fadeOut(300);
			return false;
		})
		
	});
	$('input[type="radio"]').change(function(){
		$("form").attr('radio', $('input[type="radio"]:checked').val());
	})
});
	